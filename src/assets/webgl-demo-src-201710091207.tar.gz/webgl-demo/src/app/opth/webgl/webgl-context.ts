export class OpthWebGLContext {
}
