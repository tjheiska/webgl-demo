import { OpthWebGLContext } from './webgl-context';
import { AbstractWebGLRenderer, WebGLRenderer } from './webgl-renderer';

const MAX_POINTS: number = 65536;

/**
 * A simple rendering class with xyz-data as float texture. Coordinates are 
 * fetched with normalized [0-1] float pairs.
 */
export class InstancedTextureRenderer extends AbstractWebGLRenderer {

	private program: WebGLProgram;
	private indexVbo: WebGLBuffer;
	private xyzTex: WebGLTexture;
	private texWidth: number;
	private numPoints: number;
	private shouldValidate: boolean = true;
	private uTransform: WebGLUniformLocation;

	public constructor() { super(); }

	public create( gl: WebGLRenderingContext, options?: any ) {

		if ( !gl ) throw 'invalid WebGLRenderingContext';
		super.create( gl );

		if ( !gl.getExtension('OES_texture_float') ) {
			throw 'OES_texture_float not supportted!';
		}

		this.program = super.createProgramFromSource( 
			options.vertexShaderSource, options.fragmentShaderSource );
		gl.useProgram( this.program );
		this.uTransform = gl.getUniformLocation( this.program, 
			'uTransform' );
		if ( !this.uTransform ) {
			throw 'Uniform \'uTransform\' not found.';
		}


		// Use texture max size to normalize keys
		this.texWidth = gl.getParameter( gl.MAX_TEXTURE_SIZE );
		//this.texWidth = 128;
		console.log( this.texWidth );

		this.indexVbo = gl.createBuffer();
		this.genKeys( MAX_POINTS );

		this.xyzTex = gl.createTexture();
		gl.activeTexture( gl.TEXTURE0 );
		gl.bindTexture( gl.TEXTURE_2D, this.xyzTex );

		gl.clearColor(0.0, 0.0, 0.0, 1.0);
		gl.enable( gl.DEPTH_TEST );
		gl.enable( gl.SAMPLE_ALPHA_TO_COVERAGE );
		console.log( 'antialias:' + gl.getContextAttributes().antialias );
		console.log( 'samples: ' + gl.getParameter( gl.SAMPLES ) );

	}

	private genKeys( len: number ): void {

		// generate keys
		let keys = new Float32Array(len * 2 );
		let d: number = this.texWidth;
		for ( let i : number = 0; i < len; i++ ) {
			keys[ i * 2 ] = ( i & ( d - 1 ) ) / d;
			keys[ i * 2 + 1 ] = ( i / d ); 
		}

		// vbo from key data
		const gl = this.gl;
		gl.bindBuffer( gl.ARRAY_BUFFER, this.indexVbo );
		gl.bufferData( gl.ARRAY_BUFFER, keys, 
			gl.STATIC_DRAW );

		// Connect data to program
		const vKey: GLint = 
			gl.getAttribLocation( this.program, 'vKey' );
		if ( vKey == -1 ) {
			throw 'Attribute \'vKey\' not found in program.';
		}
		gl.vertexAttribPointer( vKey, 2, gl.FLOAT, 
			false, 8, 0 );
		gl.enableVertexAttribArray( vKey );


	}

	public setDataXYZ( xyz: Float32Array ): void {

		const numPoints: number = xyz.length / 3;

		// Ensure size 2^x
		let exp: number = Math.log( numPoints ) / Math.log( 2 );
		if ( exp != Math.floor( exp ) ) throw 'data length=' +
			numPoints + ' not power of two';

		// Set width and height
		//let width: number = Math.pow( 2, Math.ceil( exp / 2 ) );
		let width: GLsizei = this.texWidth;
		if ( numPoints < this.texWidth ) width = numPoints;
		let height: GLsizei = numPoints / width;
		console.log( 'numPoints: ' + numPoints + ' width: ' + width + 
			' height: ' + height );

		// Bind and uploas
		let gl: WebGLRenderingContext = this.gl;
		gl.activeTexture( gl.TEXTURE0 );
		gl.bindTexture( gl.TEXTURE_2D, this.xyzTex );
		/*
		let test: Float32Array = new Float32Array( 3 );
		test[ 0 ] = 0.0;
		test[ 1 ] = 0.0;
		test[ 2 ] = 0.0;
		gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGB, 1, 1,
			0,	gl.RGB, gl.FLOAT, test );
		*/
		gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGB, width, height,
			0,	gl.RGB, gl.FLOAT, xyz );
		{
			let err: GLenum = gl.getError();
			if ( err != gl.NO_ERROR ) {
				throw 'Error creating texture:' + err;
			}
		}

		// Set parameters
		gl.texParameteri(gl.TEXTURE_2D, 
			gl.TEXTURE_MAG_FILTER, gl.NEAREST);
		gl.texParameteri(gl.TEXTURE_2D, 
			gl.TEXTURE_MIN_FILTER, gl.NEAREST);
		gl.texParameteri(gl.TEXTURE_2D, 
			gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D,
			gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

		// Connect texture to program
		const uCoord: WebGLUniformLocation = gl.getUniformLocation( 
			this.program, 'uCoord' );
		if ( !uCoord ) {
			throw 'Uniform \'uCoord\' not found.';
		}
		gl.uniform1i( uCoord, 0 );

		const uTexHeight: WebGLUniformLocation = gl.getUniformLocation( 
			this.program, 'uTexHeight' );
		if ( !uTexHeight ) {
			throw 'Uniform \'uTexHeight\' not found.';
		}
		gl.uniform1f( uTexHeight, < GLfloat >height );

		this.numPoints = numPoints;
	}

	public render() : void {
		try {
			this.validate();
			//console.log( 'program validation ok!')
		} catch( err ) {
			console.log( err );
			return;
		}
		let gl: WebGLRenderingContext = this.gl;
		gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT );
		gl.drawArrays( gl.POINTS, 0, 10000/*this.numPoints*/ );
		gl.flush();
		{
			let err: GLenum = gl.getError();
			if ( err != gl.NO_ERROR ) {
				throw 'Error rendering:' + err;
			}
		}
		//console.log( 'render ok' );
		//window.setTimeout( this.render, 16 );
	}

	public setTransform( matrix: Float32Array ) {
		//console.log( 'setTransform' );
		this.gl.uniformMatrix4fv( this.uTransform, false, matrix );
	}

	public validate() {
		if ( !this.shouldValidate ) return;
		// Validate program
		let gl: WebGLRenderingContext = this.gl;
		gl.validateProgram( this.program );
		if ( !gl.getProgramParameter( this.program, gl.VALIDATE_STATUS ) ) {
			let info = gl.getProgramInfoLog( this.program );
			throw 'Program validation failed.\n\n' + info;
		}
		this.shouldValidate = false;
	}

}