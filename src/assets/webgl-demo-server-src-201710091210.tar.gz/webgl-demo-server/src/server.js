"use strict";
exports.__esModule = true;
var express = require("express");
var http = require("http");
var SocketIo = require("socket.io");
var conical_helix_1 = require("./conical-helix");
var fs = require("fs");
var app = express();
//const https = require('https');
//const http = require('http');
//var server = https.createServer(options, app);
var server = http.createServer(app);
var io = SocketIo(server);
//const io = require('socket.io')(server);
//const ConicalHelixGenerator = require('conical-helix');
//const fs = require('fs');
var options = {
    key: fs.readFileSync('/home/tjheiska/th-ohjelmistot.fi.key'),
    cert: fs.readFileSync('/home/tjheiska/th-ohjelmistot.fi.crt')
};
server.listen(3000);
console.log("test");
io.on('connection', function (socket) {
    socket.emit('message', 'hello');
});
function longOperation(f) {
    var start = new Date().getTime();
    var c = 0;
    f(function () {
        //sendXyzAsPng( res, h.floats );
        if (!(c++ % 256)) {
            var end = new Date().getTime();
            var d = end - start;
            if (d > 15) {
                setImmediate(longOperation.bind(null, f));
                return false;
            }
        }
        return true;
    });
    console.log((new Date().getTime() - start) + "ms");
}
app.get('/api/point-clouds', function (req, res) {
    var notFound = true;
    var q = req.query;
    console.log(q);
    if (q.type == 'conical-helix') {
        if (q.numSamples && q.radius && q.fractionBits) {
            var h = new conical_helix_1.ConicalHelixGenerator(q.numSamples, q.radius, q.fractionBits);
            console.log('create conical helix');
            longOperation(h.read.bind(h));
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.end("Jeejeejee");
            notFound = false;
        }
    }
    if (notFound) {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end("404 Not Found");
    }
});
