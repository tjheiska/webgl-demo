import app from './server';

app.run();